# Naruto Generations — a ninja mod for Minecraft Forge 1.20.1

Chakra, releases and jutsu, levels and stats, Ryo, and ninja tools.

## Building the jar

**With GitHub (no Java needed):** upload `Naruto Generations.zip` (still zipped) to your repository, after
deleting the old zip (the workflow builds every zip it finds). The "Build mod jar" workflow runs on its own. When it's green, download **shinobiarts-jar**,
unzip it, and put `Naruto Generations-1.0.0.jar` in your profile's `mods` folder (remove any older
`shinobiarts-1.0.0.jar` first: two copies of the mod crash the game).

**On your PC:** install JDK 17, open a terminal in this folder and run `gradlew build`
(`./gradlew build` on Mac/Linux). The jar appears in `build/libs/`.

## Controls (rebind in Options → Controls → Naruto Generations)

| Key | Action |
|---|---|
| **Right-click** | Cast the selected jutsu of the release you're holding |
| **G / H** | Move the jutsu arrow right / left |
| **J** | Stats menu |
| **Z** (hold) | Charge chakra (standing still also gathers Senjutsu) |
| **B** | Toggle Sage Mode |
| **V** | Switch your eyes on/off (Sharingan, Byakugan; cycles if you own both) |
| **Shift + Space** | Ninja Jump from the ground (15 chakra, no cooldown) |

Your health bar sits above the hotbar where the hearts were. The panel to the left of the hotbar shows
Ryo, level, the chakra figure with the soft chakra and Senjutsu bars, and the jutsu slots of the release you're holding.
Every time you join a world or server, a clickable Discord invite appears in chat.

## How it works

### Clans
There are **30 clans**. New players start without one and roll it with **`/clanroll`**:
- Each `/clanroll` rolls a new clan (replacing the last one). Every player gets **2 rolls** (`clanRolls` in the config).
- **`/clanroll claim`** locks the current clan in for good. After that, `/clanroll` says
  *"Sorry, you already claimed your clan."*
- With no rolls left, `/clanroll` says *"You have used all of your rerolls!"* and the last rolled clan stays.
- Rolling away from Uchiha takes back the Sharingan you got with it; clans with a fixed nature (e.g. Uchiha = Fire)
  set your affinity unless you've already revealed it with Chakra Paper.
- Players from older versions keep the clan they had, already claimed. `/shinobi clanroll <player> reset` gives
  someone their rolls back.

The clan's bonuses are passive and always on. Hover over your clan in the stats menu (J), or type `/clan`, to see
them. `/clan list` shows every clan and its chance, and `/clan info <clan>` shows any clan's bonuses. Rare and
Mythic rolls are announced to the whole server.

| Rarity | Chance (each) | Clans |
|---|---|---|
| Mythic | 1 in 100,000 per roll | Ōtsutsuki |
| Rare | 1 in 138 per roll | Uchiha, Senju, Uzumaki |
| Uncommon | 1 in 46 per roll | Hyūga, Kurama, Kaguya, Yuki, Kazekage, Chinoike, Hagoromo |
| Common | 1 in 23 per roll | Nara, Akimichi, Yamanaka, Aburame, Inuzuka, Sarutobi, Hatake, Shimura, Fūma, Hōzuki, Hoshigaki, Karatachi, Shirogane, Yotsuki, Kamizuru, Iburi, Tsuchigumo, Funato, Taketori |

| Clan | Bonuses |
|---|---|
| **Ōtsutsuki** | Byakugan, +60% max chakra, +6 health, regen, +15% all jutsu damage, 15% shorter cooldowns, hits drain 6 chakra, 30% drain resistance, 8% dodge |
| **Uchiha** | Fire affinity, Sharingan at birth, +20% Fire jutsu, +15% genjutsu, Mangekyō and Amaterasu |
| **Senju** | Earth affinity, +30% max chakra, +4 health, regen, +20% knockback resistance, +15% Earth and Water jutsu (Wood Release blood) |
| **Uzumaki** | +50% max chakra, +50% chakra regen, +4 health, regen, 50% chakra-drain resistance, sealing chains (15% slow on hit), double shadow clones |
| Hyūga | Byakugan, +25% bare-hand damage, hits drain 5 chakra (Gentle Fist), Palm Rotation |
| Kurama | +35% genjutsu, +15% Yin Yang jutsu |
| Kaguya | +20% melee damage, +4 armor (bone) |
| Yuki | Water affinity, +15% Water and Wind jutsu (Ice Release), 20% slow on hit |
| Kazekage | Earth affinity, 30% less projectile damage, +2 armor (sand shield), +15% Earth jutsu |
| Chinoike | +30% genjutsu, 15% blind on hit (Ketsuryūgan) |
| Hagoromo | +10% all jutsu damage, +15% chakra regen |
| Nara | +15% XP, 10% shorter cooldowns, Shadow Possession |
| Akimichi | +6 health, +15% melee damage, +30% knockback resistance |
| Yamanaka | +20% genjutsu, 12% confuse on hit (mind techniques) |
| Aburame | Hits drain 4 chakra (insects), sense creatures while sneaking |
| Inuzuka | +10% speed, +10% melee damage, night vision, sense creatures while sneaking |
| Sarutobi | Fire affinity, +15% Fire and Earth jutsu, +10% chakra regen |
| Hatake | Lightning affinity, +15% Lightning jutsu, +10% sword damage, 10% shorter cooldowns |
| Shimura | Wind affinity, +15% Wind jutsu, sense creatures while sneaking |
| Fūma | +30% kunai and shuriken damage, +5% speed |
| Hōzuki | Water affinity, +15% Water jutsu, 12% dodge (hydrification), water breathing |
| Hoshigaki | Water affinity, +30% max chakra, +10% melee damage, water breathing, fast swimming |
| Karatachi | Water affinity, +15% Water jutsu, 8% dodge (mist) |
| Shirogane | +15% kunai and shuriken damage, 25% poison on hit (puppets) |
| Yotsuki | Lightning affinity, +15% Lightning jutsu, +12% speed, +10% melee damage |
| Kamizuru | 25% slow and 15% poison on hit (bees and honey), sense creatures while sneaking |
| Iburi | 15% dodge (smoke), 50% less fall damage, +5% speed |
| Tsuchigumo | +12% all jutsu damage, +2 armor (barriers) |
| Funato | Water affinity, +10% Water jutsu, +10% sword damage, water breathing, fast swimming |
| Taketori | +20% bare-hand damage, +15% sword damage |

"Regen" heals 1 health every 5 seconds (half that for Ōtsutsuki). "Sense" makes creatures within 16 blocks glow while you
sneak. The chances are set in the `clans` config section (a weight per tier, and `mythicChance` for Ōtsutsuki); `/shinobi clan <player> <clan>` sets one
directly.

### Releases and jutsu
- There are 7 release scrolls: Fire, Water, Wind, Lightning, Earth, Yin Yang, and Ninjutsu.
  **Hold one** (either hand) to equip it: you hold its octagon emblem, and the HUD shows its jutsu slots.
- New players get the **Ninjutsu** release scroll, empty at first.
- **Chakra Paper** reveals your nature affinity and gives you that release scroll. **Training Scrolls**
  unlock more natures, including Yin Yang.
- **Jutsu scrolls** teach a jutsu permanently and add it to its release's slots. Shadow Clone,
  Rasengan, Substitution, Body Flicker and clan jutsu go in Ninjutsu.
- Every jutsu has a **rank from the show**, D (weakest) to S (strongest). The rank is on the scroll's tooltip
  and colors its name, the creative tab lists scrolls from D to S, and each rank needs a minimum level to
  learn (configurable in `jutsuRanks`):

| Rank | Level | Jutsu |
|---|---|---|
| D | 1 | Substitution, Body Flicker, Hell Viewing, Water Bullet |
| C | 15 | Great Fireball, Phoenix Flower, Water Prison, Gale Palm, Great Breakthrough, Mind Fog, Shadow Possession |
| B | 40 | Great Fire Annihilation, Water Dragon, Vacuum Blade, Earth Wall, Rock Armor, Rising Spikes, Shadow Clone |
| A | 90 (Chunin) | Lightning Armor, Chidori, Thunder Strike, Mystical Palm, Rasengan, Eight Trigrams Palm Rotation |
| S | 175 (Jonin) | Vitality Surge, Amaterasu, Rasenshuriken |

- **Hold right-click to charge** a jutsu that deals damage, and let go to cast it. A counter under the crosshair shows
  the charge (0-100%, then a pulsing gold **MAX**) and the damage it will do: a quick tap casts at x0.6, a full charge at
  x1.5. A full charge takes 0.5 s for D rank up to 2.5 s for S rank; chakra gathers around your hands and a chime
  plays when it's full. The counter turns red if the jutsu is still cooling down or you're short on chakra.
  Utility jutsu (Substitution, Body Flicker, armors, walls, healing, Shadow Clone...) still cast the moment you click.
  Everything is in the `charging` config section (set `enabled = false` to cast every jutsu on click).
- **Every jutsu costs 15% of your max chakra** (15 out of 100; more Ninjutsu points mean more casts) and has a
  short cooldown. Change the share with `jutsuCostPercent` in the config.
- Jutsu scrolls are colored by the release they go into, training scrolls by their nature: Fire red, Water blue,
  Wind teal, Lightning yellow, Earth brown, Yin Yang black, Ninjutsu (and clan jutsu) purple. Their inventory
  pictures are rendered from the 3D scrolls.

### Sharingan
- **Anyone can own the Sharingan.** Uchiha are born with a 1-tomoe Sharingan; anyone else gets one by taking it.
- **Evolution, one stage at a time:** 1 tomoe → 2 tomoe at level 30 → 3 tomoe at level 60 → **Mangekyou** once
  you're level 100 with 3 tomoe *and* survive a near-death experience (health at or below 5% of max).
- Press **V** to switch it on (it drains chakra). Your face shows the eyes of your stage to everyone, and the
  eyes flash across your screen when you switch them on or they evolve.
- Stronger stages dodge more hits (12% / 18% / 25% / 32%, raised by Genjutsu, max 50%) and copy jutsu from
  farther away. **Amaterasu** can be learned by anyone with a Sharingan, but casting it needs an active Mangekyou.
- **Taking eyes:** defeating a Sharingan user in PvP (a kill that gives PvP rewards) gives you a **Sharingan Eye**.
  Right-click it to implant it: you get its stage, limited by your level (a Mangekyou eye needs level 100).
  Players who weren't born Uchiha lose their Sharingan when it's taken; Uchiha keep their bloodline eyes.
- The **Sharingan** helmet (2 Eyes of Ender and a block of redstone, in a row) is cosmetic: it shows the eyes on
  your face (your own stage if your Sharingan is on, 3 tomoe otherwise).

### Shadow clones
- Clones copy your **hand jutsu**: cast Rasengan, Chidori or Rasenshuriken and each clone gets one too. They
  use Rasengan up close or **throw it** from range, dash in with Chidori, and throw Rasenshuriken.
- While your Sharingan is on, your clones have it too (same stage, they can dodge hits); switch it off and
  theirs goes away.

### Combat tag and vault
- Hitting or being hit by another player (directly, with jutsu or through clones) puts **both** of you in
  combat for 60 seconds: `In Combat (60) - Username` shows at the top of the screen.
- In combat **every command is blocked** (from any mod), and **logging out kills you**; your opponent gets the kill.
- `/vault` opens your personal 54-slot vault. Vault items stay through death.

### Teams
- `/team create <name>`, `/team invite <player>` (they click [Accept]), `/team leave`, `/team kick <name>`,
  `/team disband`, `/team info`. Up to 4 players per team. Your team and who's online show in the stats menu (J).

### Levels and stats
- Gain XP by killing hostile mobs (5 XP each, 100 XP for the first level), from PvP, and from
  **Ninja EXP Bottles** (100 XP each). Update 2 adds quests and bandits.
- **XP Boost Tokens** (1.5x or 2.5x, for 30 minutes or 1 hour): right-click to multiply the XP you earn from
  mobs and PvP. The timer (shown on the HUD) only runs while you're online. A stronger token replaces a
  weaker boost; the same one adds time.
- Each level gives **4 stat points** and **250 Ryo**.
- **Ranks cap your level:** Genin 75, Chunin 150, Jonin 250, Anbu 400, Sannin 500. At the cap, XP is saved
  until you're promoted (by a Kage in Update 2, or `/shinobi rank`).
- Spend points in the stats menu (J); shift-click adds 5. Resetting refunds every point for Ryo
  (500 + 100 per level), with a confirmation screen.
- New players start with a **Frog Wallet** and **3 kunai** (plus the empty Ninjutsu release).

### Jutsu Points and upgrades
- Each level-up has a **35% chance** to give **2-6 Jutsu Points**.
- In the stats menu (J), the **Jutsu** tab lists your learned jutsu that deal damage. **20 points** upgrade one of them
  by **+15% damage**, up to **5 times** (+75%). The bonus applies wherever that jutsu deals damage: Rasengan's punch,
  projectiles, and the copies your shadow clones throw.
- Utility jutsu (Substitution, armors, walls, healing, Shadow Clone itself) can't be upgraded.
- All of the numbers are in the `jutsuUpgrades` config section; `/shinobi jutsupoints` gives points for testing.

| Stat | Effect per point (default) |
|---|---|
| Taijutsu | +0.5 punch damage (bare hand or holding a release scroll) |
| Kenjutsu | +0.4 sword damage |
| Genjutsu | +2% Sharingan dodge/copy range, Amaterasu, Shadow Possession and Yin illusions |
| Medical | +1 max health (half a heart), stronger Yang healing |
| Speed | +1% movement speed (max 50 points, the only capped stat) |
| Ninjutsu | +5 max chakra, slightly faster chakra regen |
| Senjutsu | +10 max natural energy for Sage Mode |

### PvP
- Landing hits on other players gives a little XP (max 30 per minute). Defeating a player gives XP and Ryo,
  more for higher-level opponents.
- **Level-gap rule (both ways):** fights between players whose levels are too far apart give no rewards.
  Strong players get nothing for beating new players, and new players get nothing for beating strong ones
  (so nobody can boost an alt). Anyone can still fight and kill anyone. The allowed gap is the larger of
  10 levels and half the lower player's level: level 1 and level 12+ players get nothing from each other,
  and a level 100 player can be rewarded against levels 50-150.
- No rewards for beating the same player again within 10 minutes, or for killing an AFK player.
  Shadow clone and jutsu kills count as yours. All values are in the `pvp` config section.

### Ryo and the Frog Wallet
- Coins: **Bronze = 100**, **Silver = 500**, **Gold = 1,000** Ryo.
- Right-click the **Frog Wallet**: its mouth opens to show your Ryo and the deposit/withdraw buttons.
  Click the tongue to close it.
- Your Ryo is stored on your player, not in the wallet item. Dropping, losing or copying a wallet never
  loses or duplicates money, and every transfer is checked by the server.

### Ninja weapons
All of them are swords, so Kenjutsu adds to their damage. They live in the **Ninja Tools** creative tab
with the kunai, shuriken and explosive tags. Damage is the number on the tooltip (change it in the
`weapons` config section).

| Weapon | Damage | Speed | Reach | Special |
|---|---|---|---|---|
| Samehada | 34 | 0.7 | +1 | Eats chakra: steals 10 from players you hit, and gives you 5 on every hit |
| Kubikiribocho | 32 | 0.8 | +1 | Repairs itself with every hit |
| Hidan's Triple-Bladed Scythe | 24 | 0.9 | +1.5 | Heals you for 20% of the damage you deal |
| Sword of Fire | 19 | 1.2 | | Sets targets on fire |
| Shakujo Staff | 17 | 1.1 | +1.5 | Heavy knockback |
| Kusanagi Sword | 15 | 1.8 | | Chidori Flow: hits spend 4 chakra to paralyse the target |
| Katana | 11 | 1.6 | | |

### Sage Mode
Invest in Senjutsu, then hold **Z** while standing still to gather natural energy (green bar).
Press **B** for Sage Mode: Strength, Resistance, Jump Boost and +25% jutsu damage until the energy runs out.

### Villages and the quest board (Update 2)
Five villages by default: Hidden Leaf (`leaf`), Sand (`sand`), Mist (`mist`), Cloud (`cloud`) and Stone (`stone`).
The list is in the config (`id:Display Name`), so you can rename them or add more.

**Joining a village** is done with permissions (LuckPerms or any permission plugin that works with Forge):

| Permission node | Gives |
|---|---|
| `shinobiarts.village.<id>` | membership, e.g. `shinobiarts.village.leaf` |
| `shinobiarts.village.<id>.kage` | Kage of that village (also counts as a member) |
| `shinobiarts.village.<id>.advisor` | Village Advisor of that village (the player also needs membership) |

Example: `/lp user Steve permission set shinobiarts.village.leaf true`. Membership is re-checked whenever a player
joins or opens the board. Without a permission plugin, operators use `/shinobi village` and `/shinobi kage` (below).

**`/village`** (or `/village <id>`) opens your village's quest board:
- Tabs for **Hourly** (2 quests), **Daily** (3), **Weekly** (2), **Monthly** (1) and **Kage** quests. Random quests
  are rolled for each player when the period starts, and the tab shows when they refresh.
- **Accept** or **Decline** each quest. Only accepted quests count.
- Quest kinds: defeat Ninja Bandits, defeat hostile mobs, defeat enemy players, catch fish, and bring items
  (logs, wheat, bread, iron, diamonds). Item quests complete as soon as you carry the items.
- **Claim** pays the reward (EXP bottles plus Ryo, straight into your wallet balance) and hands the items in:
  **every handed-in item goes to the village storage**, for random quests and Kage quests alike. If the storage
  is full, the quest waits until the Kage makes room.
- The bottom of the board shows the village's **Advisors** ("Need help? Advisors: ..."), online ones in green.

**`/village <id> admin`** opens the **Kage menu** (Kage only):
- **Post a quest**: hold the item you want brought in, then set the amount, EXP bottles and Ryo (capped by the config).
  Every member sees it under the Kage tab. Items handed in for Kage quests go to the village storage.
- **Remove** posted quests (×), **promote or demote** online members (+ / −, Genin → Chunin → Jonin; Anbu only if
  the config allows it).
- **A** appoints (or removes) a **Village Advisor**: the person players should go to when they need help.
  Advisors' names are blue in the member list.
- **Village Storage**: a 54-slot chest shared by the village, opened from the Kage menu.

**Village Advisors** show as **[Advisor]** (and Kages as **[Kage]**) in front of their name in chat and the player
list (turn off with `showTitlesInChat`), on the quest board, and on their own stats page. They come from the Kage
menu, `/shinobi advisor`, or the `.advisor` permission node.

### Ninja Bandits
Rogue ninja who roam the overworld in groups of 1-3, by day and night, anywhere with open sky. Each one uses a
nature: **Fire** (fireballs), **Water** (water bullets) or **Earth** (spikes from the ground under you). The colour
of their scarf and headband shows which. They cast from range and close in with a kunai. They drop 100-400 Ryo in coins
(more with Looting) and sometimes their kunai, and count toward bandit quests. There's a spawn egg in the
Naruto Generations creative tab.

## Recipes (shapeless unless noted)

**Blank Scroll** = 3 paper + stick.

| Item | Recipe |
|---|---|
| Release scroll | Blank Scroll + 4 of the release's item (see below) |
| Training Scroll | Blank Scroll + 3 of the nature's item + emerald |
| Elemental jutsu scroll | Blank Scroll + 2 of the nature's item, plus a gold ingot or diamond for the stronger ones (same recipes as before; see `RECIPE_EXTRA` in `tools/make_resources.py`) |
| Frog Wallet | 2 leather + slime ball + lime dye + string |
| Kubikiribocho (shaped) | 2 iron blocks diagonally above a netherite ingot |
| Samehada (shaped) | heart of the sea, prismarine, netherite ingot on a diagonal (netherite at the bottom) |
| Hidan's Scythe (shaped) | 3 iron blocks across the top, netherite ingot in the middle, stick bottom-left |
| Sword of Fire (shaped) | gold block, netherite ingot, blaze rod on a diagonal (blaze rod at the bottom) |
| Shakujo Staff (shaped) | bell, gold block, gold block on a diagonal (bell at the top) |
| Kusanagi Sword (shaped) | 2 diamonds diagonally above a stick |
| Katana (shaped) | 2 iron ingots diagonally above a stick |
| Kunai ×3 (shaped) | iron ingot diagonally above a stick |
| Shuriken ×4 (shaped) | iron ingot in a cross of 4 iron nuggets |
| Explosive Tag ×2 | paper + gunpowder + redstone |
| Chakra Pill ×2 | sugar + sweet berries + glowstone dust |
| Chakra Paper ×2 | paper + lapis lazuli |

Nature items: Fire = blaze powder, Water = prismarine shard, Wind = feather, Lightning = copper ingot,
Earth = clay ball, Yin Yang = amethyst shard, Ninjutsu = lapis lazuli.
Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon; Ninjutsu and clan jutsu have special
recipes (see `tools/make_resources.py`).

## Admin commands (operators)

```
/shinobi info [player]
/shinobi xp <player> <amount>
/shinobi level <player> <level>
/shinobi rank <player> <genin|chunin|jonin|anbu|sannin>
/shinobi ryo <player> add|set <amount>
/shinobi release <player> <fire|water|wind|lightning|earth|yin_yang|ninjutsu>
/shinobi learn <player> <jutsu|all>        /shinobi forget <player> <jutsu|all>
/shinobi nature <player> <nature>          /shinobi clan <player> <clan>   (any of the 30; see /clan list)
/shinobi clanroll <player> reset           (gives a player their /clanroll uses back and unclaims their clan)
/shinobi refill <player>                   /shinobi reset <player>
/shinobi sharingan <player> <0-4>          (0 none, 1-3 tomoe, 4 Mangekyou)
/shinobi village <player> <village|none>   (puts a player in a village without a permission plugin)
/shinobi kage <player> <village|none>      (makes a player Kage; "none" removes the Kage title)
/shinobi advisor <player> <village|none>   (makes a player a Village Advisor; "none" removes it)
/shinobi jutsupoints <player> add|set <amount>
```

Everyone: `/clanroll`, `/clanroll claim`, `/vault`, `/team ...`, `/village`, `/village list`, `/clan`, `/clan list`, `/clan info <clan>`
(all blocked while in combat). XP Boost Tokens have no recipe yet: hand them out
with `/give <player> shinobiarts:xp_boost_2_5x_60m` (or `_1_5x_30m`, `_1_5x_60m`, `_2_5x_30m`).

Quick test: `/shinobi learn @s all`, `/shinobi rank @s sannin`, `/shinobi level @s 20`, `/shinobi ryo @s add 5000`,
`/shinobi release @s fire`.

## Config

Each world has `saves/<world>/serverconfig/shinobiarts-server.toml`, and servers send it to every player
who joins. It holds XP curve, rank level caps, points and Ryo per level, every stat's value per point, the Speed cap,
reset cost, chakra regen, Senjutsu rates, Ninja Jump cost/power, damage and cooldown
multipliers, jutsu griefing, PvP rewards, each weapon's damage and special effect strength, jutsu chakra cost,
rank level requirements, mob XP, Sharingan stage levels and near-death health, eye theft, combat tag length,
command blocking, combat-log kills, team size, the village list, how many hourly/daily/weekly/monthly quests each
player gets, the Kage's reward caps and quest limit, whether a Kage can promote to Anbu, and the bandits' Ryo
drops and jutsu damage, how many times each player can use /clanroll, the chance of each clan rarity tier and whether rare rolls are announced, Jutsu Point chance/amount, upgrade cost, damage per upgrade and max upgrades, and whether
[Kage]/[Advisor] titles show in chat. Ninja Bandit spawning (weight 10, groups of 1-3, all overworld biomes) is in
`data/shinobiarts/forge/biome_modifier/ninja_bandits.json`; a datapack can override it.

## Art and models

- The Fire/Water/Wind/Lightning/Earth icons are cut from your chart by `tools/cut_nature_icons.py`.
- **The Yin Yang and Ninjutsu icons are placeholders.** To replace one, save a square PNG as
  `src/main/resources/assets/shinobiarts/textures/nature/<yin_yang|ninjutsu>.png`, create an empty file
  `.<name>.provided` next to it, and run `python3 tools/make_textures.py` to rebuild the item icons.
- 3D models come from `tools/source_art/*.glb` and `tools/source_art/weapons/*.obj` (with their textures).
  `python3 tools/convert_models.py` turns them into Forge OBJ models: kunai, shuriken, the weapons, and the
  jutsu, training (地) and blank scrolls. The shuriken uses `source_art/shuriken_metal.png` because its own
  color is nearly black.
  `python3 tools/recolor_scrolls.py` then makes the jutsu scroll's color for each release.
  Samehada uses `source_art/samehada_recolor.png` (blue shark-skin scales, off-white bandages, blue grip), made by
  `python3 tools/recolor_samehada.py`. Its model tiles its texture, which Minecraft can't do, so the converter
  moves every triangle's texture coordinates back into range (that was what made it look glitchy).
  Each item holds exactly one scroll. The size of each weapon is its `length` in `MODELS`.
- Inventory icons stay flat so they're easy to read; the 3D model shows in your hand, on the ground and in flight.
  The kunai, shuriken, weapon and scroll icons are rendered from their 3D models
  (`tools/convert_models.py`, then `tools/recolor_scrolls.py` for the scroll colors).
- The chakra figure on the HUD is `source_art/chakra_figure.png` (cut out of your picture), saved small as
  `textures/gui/chakra_figure.png`. All Sharingan art (eyes on faces for each stage, the screen flash, the
  helmet and eye icons, and the HUD's round eye icons) is drawn by `tools/make_sharingan.py`; the XP token icons
  by `tools/make_tokens.py`.
- Above the HUD scroll sits a row of slots: your eyes (Sharingan at its stage or Byakugan, bright with a red or
  violet frame while active) and the four armor pieces you're wearing, with durability bars.

## Saves

All player data lives in one place (`ninja/NinjaData.java`, changed only through
`ninja/PlayerDataManager.java`). It has a `DataVersion`; saves from the first version are upgraded
automatically: learned jutsu are kept, and old chakra training becomes stat points.

## Project layout

```
src/main/java/com/shinobiarts/
  ninja/      player data (NinjaData), PlayerDataManager, clans, natures, stats
  jutsu/      jutsu list, effects, casting, per-tick logic, key actions
  item/       release scrolls, jutsu/training scrolls, coins, wallet, EXP bottle, weapons
  entity/     jutsu projectiles, thrown weapons, explosive tags, shadow clones
  client/     HUD, stats/reset/wallet screens, keybinds, renderers
  network/    key/menu requests (client -> server) and data sync (server -> client)
  command/    /shinobi
tools/        generators for icons, 3D models, models/recipes/lang (run with Python 3)
```
