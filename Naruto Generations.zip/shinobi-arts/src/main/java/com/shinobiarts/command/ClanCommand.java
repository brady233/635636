package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.shinobiarts.Config;
import com.shinobiarts.event.CommonEvents;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;

/**
 * /clan              your clan, its rarity and bonuses
 * /clan list         every clan by rarity, with its chance (click one for its bonuses)
 * /clan info &lt;clan&gt;  any clan's rarity and bonuses
 * /clanroll          rolls a new clan (a few uses per player: "clanRolls" in the config)
 * /clanroll claim    locks the current clan in for good
 */
public final class ClanCommand {
    private static final SuggestionProvider<CommandSourceStack> CLANS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Clan.values()).filter(c -> c != Clan.NONE).map(Clan::id), builder);

    private ClanCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("clan")
                .executes(ClanCommand::mine)
                .then(Commands.literal("list").executes(ClanCommand::list))
                .then(Commands.literal("info")
                        .then(Commands.argument("clan", StringArgumentType.word()).suggests(CLANS)
                                .executes(ctx -> {
                                    Clan clan = Clan.byId(StringArgumentType.getString(ctx, "clan").toLowerCase(java.util.Locale.ROOT));
                                    if (clan == null || clan == Clan.NONE) {
                                        ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.unknown_clan"));
                                        return 0;
                                    }
                                    show(ctx.getSource(), clan, "message.shinobiarts.clan_info");
                                    return 1;
                                }))));
        dispatcher.register(Commands.literal("clanroll")
                .executes(ClanCommand::roll)
                .then(Commands.literal("claim").executes(ClanCommand::claim)));
    }

    /** /clanroll: rolls a new clan, unless the player claimed theirs or used every roll. */
    private static int roll(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.isClanClaimed()) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claimed"));
            return 0;
        }
        int max = Config.i(Config.CLAN_ROLLS);
        if (d.getClanRolls() >= max) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_none_left"));
            return 0;
        }
        Clan clan = Clan.random(player.getRandom());
        d.setClanRolls(d.getClanRolls() + 1);
        d.applyRolledClan(clan);
        PlayerDataManager.applyStatEffects(player);
        ModNetwork.sync(player);
        SharinganManager.broadcastEyes(player);
        CommonEvents.announceClan(player, d, true);

        int left = max - d.getClanRolls();
        if (left > 0) {
            MutableComponent line = Component.translatable("message.shinobiarts.clanroll_left", left).withStyle(ChatFormatting.YELLOW)
                    .append(button("message.shinobiarts.clanroll_claim_button", "/clanroll claim", ChatFormatting.GREEN))
                    .append(" ")
                    .append(button("message.shinobiarts.clanroll_again_button", "/clanroll", ChatFormatting.AQUA));
            player.sendSystemMessage(line);
        } else {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_last", clan.displayName()).withStyle(ChatFormatting.YELLOW));
        }
        if (!d.availableDojutsu().isEmpty()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.dojutsu",
                    d.dojutsuName(d.availableDojutsu().get(0))).withStyle(ChatFormatting.GOLD));
        }
        return 1;
    }

    /** /clanroll claim: keeps the current clan for good. */
    private static int claim(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.isClanClaimed()) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claimed"));
            return 0;
        }
        if (d.getClan() == Clan.NONE) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.clanroll_claim_first"));
            return 0;
        }
        d.setClanClaimed(true);
        ModNetwork.sync(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.clanroll_claim_done", d.getClan().displayName())
                .withStyle(ChatFormatting.GREEN));
        return 1;
    }

    /** A clickable chat button that runs a command. */
    public static MutableComponent button(String key, String command, ChatFormatting color) {
        return Component.translatable(key).withStyle(Style.EMPTY.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(command))));
    }

    private static int mine(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (d.getClan() == Clan.NONE) {
            ctx.getSource().sendSuccess(() -> Component.translatable("message.shinobiarts.clan_none").withStyle(ChatFormatting.YELLOW), false);
            return 1;
        }
        show(ctx.getSource(), d.getClan(), "message.shinobiarts.clan_yours");
        return 1;
    }

    private static void show(CommandSourceStack source, Clan clan, String headerKey) {
        MutableComponent msg = Component.translatable(headerKey, clan.displayName(), clan.rarityText()).withStyle(ChatFormatting.GOLD);
        for (Component line : clan.describe()) msg.append(Component.literal("\n - ").withStyle(ChatFormatting.DARK_GRAY)).append(line);
        source.sendSuccess(() -> msg, false);
    }

    /** One line per rarity tier, rarest first; each clan name runs /clan info when clicked. */
    private static int list(CommandContext<CommandSourceStack> ctx) {
        MutableComponent msg = Component.translatable("message.shinobiarts.clan_list").withStyle(ChatFormatting.GOLD);
        Clan.Rarity[] tiers = Clan.Rarity.values();
        for (int t = tiers.length - 1; t >= 0; t--) {
            Clan.Rarity tier = tiers[t];
            if (tier == Clan.Rarity.CLANLESS) continue;
            MutableComponent line = Component.literal("\n").append(tier.displayName()).append(Component.literal(": ").withStyle(ChatFormatting.GRAY));
            boolean first = true;
            double each = 0;
            for (Clan clan : Clan.values()) {
                if (clan.rarity() != tier) continue;
                if (!first) line.append(Component.literal(", ").withStyle(ChatFormatting.GRAY));
                first = false;
                each = clan.chance();
                line.append(clan.displayName().withStyle(Style.EMPTY.withColor(clan.color())
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/clan info " + clan.id()))
                        .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.translatable("message.shinobiarts.clan_click")))));
            }
            line.append(Component.translatable("message.shinobiarts.clan_each", Clan.formatChance(each)).withStyle(ChatFormatting.DARK_GRAY));
            msg.append(line);
        }
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }
}
