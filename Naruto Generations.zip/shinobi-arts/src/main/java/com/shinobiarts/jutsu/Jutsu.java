package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import javax.annotation.Nullable;

/**
 * One technique. The {@link Action} does the actual work on the server and returns false
 * if the jutsu fizzled (no target, no room...), in which case no chakra or cooldown is spent.
 */
public final class Jutsu {
    @FunctionalInterface
    public interface Action {
        boolean perform(ServerPlayer player, NinjaData data);
    }

    private final String id;
    private final ChakraNature nature;
    @Nullable
    private final Clan clan;
    private final JutsuRank rank;
    private final int cooldown;
    private final boolean needsDojutsu;
    private final Action action;

    Jutsu(String id, ChakraNature nature, @Nullable Clan clan, JutsuRank rank, int cooldownTicks, boolean needsDojutsu, Action action) {
        this.id = id;
        this.nature = nature;
        this.clan = clan;
        this.rank = rank;
        this.cooldown = cooldownTicks;
        this.needsDojutsu = needsDojutsu;
        this.action = action;
    }

    public String id() {
        return id;
    }

    public ChakraNature nature() {
        return nature;
    }

    /** Clan that is allowed to learn this jutsu, or null if anyone can. */
    @Nullable
    public Clan clan() {
        return clan;
    }

    /** D (weakest) to S (strongest), as in the show. */
    public JutsuRank rank() {
        return rank;
    }

    /** Chakra this jutsu costs the player: a fixed share of their max chakra (15% by default). */
    public float cost(NinjaData data) {
        return data.maxChakra() * com.shinobiarts.Config.f(com.shinobiarts.Config.JUTSU_COST_PERCENT);
    }

    public int cooldown() {
        return cooldown;
    }

    public boolean needsDojutsu() {
        return needsDojutsu;
    }

    public Action action() {
        return action;
    }

    /** Minimum player level needed to learn this from a scroll (set per rank in the config). */
    public int requiredLevel() {
        return rank.requiredLevel();
    }

    /** The release whose slots this jutsu goes into. Clan and non-elemental jutsu belong to Ninjutsu. */
    public ChakraNature release() {
        return clan != null ? ChakraNature.NONE : nature;
    }

    /** Texture group for the scroll item: fire, water, wind, lightning, earth, basic or clan. */
    public String category() {
        if (clan != null) return "clan";
        return nature == ChakraNature.NONE ? "basic" : nature.id();
    }

    public MutableComponent displayName() {
        return Component.translatable("jutsu.shinobiarts." + id).withStyle(clan != null ? clan.color() : nature.color());
    }

    public MutableComponent description() {
        return Component.translatable("jutsu.shinobiarts." + id + ".desc");
    }
}
