package com.shinobiarts.jutsu;

import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.Stat;
import com.shinobiarts.registry.ModBlocks;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEffects;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;

import static com.shinobiarts.jutsu.JutsuUtil.dmg;

/** Server-side implementation of every jutsu. Each returns false if it fizzled (nothing is spent). */
public final class JutsuEffects {
    private static final DustParticleOptions WATER_DUST = new DustParticleOptions(new Vector3f(0.25f, 0.55f, 1.0f), 1.6f);
    private static final DustParticleOptions CHAKRA_DUST = new DustParticleOptions(new Vector3f(0.45f, 0.8f, 1.0f), 1.2f);
    private static final DustParticleOptions SHADOW_DUST = new DustParticleOptions(new Vector3f(0.05f, 0.05f, 0.08f), 1.5f);
    private static final DustParticleOptions BLACK_FLAME = new DustParticleOptions(new Vector3f(0.08f, 0.0f, 0.1f), 2.0f);
    private static final DustParticleOptions YIN_DUST = new DustParticleOptions(new Vector3f(0.35f, 0.1f, 0.55f), 1.6f);
    private static final DustParticleOptions YANG_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.92f, 0.6f), 1.2f);

    private JutsuEffects() {}

    private static void noTarget(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    // ================================================================ FIRE

    public static boolean fireball(ServerPlayer p, NinjaData d) {
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.FIRE_BALL, 1.3f, 0f, dmg(10f));
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.BLAZE_SHOOT, 1.0f, 0.7f);
        return true;
    }

    public static boolean phoenixFlower(ServerPlayer p, NinjaData d) {
        for (float yaw : new float[]{-16f, -8f, 0f, 8f, 16f}) {
            JutsuProjectile.shoot(p, JutsuProjectile.Kind.FIRE_SMALL, 1.6f, yaw, dmg(6f));
        }
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.FIRECHARGE_USE, 1.0f, 1.2f);
        return true;
    }

    public static boolean fireAnnihilation(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : JutsuUtil.inCone(p, 12, 35)) {
            e.hurt(ModDamage.jutsu(level, p, p), dmg(9f));
            e.setSecondsOnFire(8);
        }
        JutsuUtil.stream(level, ParticleTypes.FLAME, eye.add(look), look, 30, 160, 0.5, 1.1);
        JutsuUtil.stream(level, ParticleTypes.LARGE_SMOKE, eye.add(look), look, 25, 30, 0.3, 0.6);
        if (JutsuUtil.griefing(level, p)) {
            RandomSource r = level.getRandom();
            for (int i = 0; i < 24; i++) {
                Vec3 dir = JutsuUtil.randomConeDir(look, 30, r);
                BlockPos pos = BlockPos.containing(eye.add(dir.scale(3 + r.nextDouble() * 9)));
                for (int k = 0; k < 5; k++, pos = pos.below()) {
                    if (BaseFireBlock.canBePlacedAt(level, pos, Direction.UP)) {
                        level.setBlockAndUpdate(pos, BaseFireBlock.getState(level, pos));
                        break;
                    }
                }
            }
        }
        JutsuUtil.sound(level, eye, SoundEvents.BLAZE_SHOOT, 1.5f, 0.5f);
        JutsuUtil.sound(level, eye, SoundEvents.FIRECHARGE_USE, 1.5f, 0.6f);
        return true;
    }

    // ================================================================ WATER

    public static boolean waterBullet(ServerPlayer p, NinjaData d) {
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.WATER_BULLET, 2.2f, 0f, dmg(7f));
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.PLAYER_SPLASH, 0.8f, 1.6f);
        return true;
    }

    public static boolean waterPrison(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 6));
        target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 120, 2));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1));
        target.clearFire();
        target.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
        if (target instanceof Mob mob) mob.getNavigation().stop();
        Vec3 c = target.getBoundingBox().getCenter();
        JutsuUtil.particles(level, WATER_DUST, c, 60, target.getBbWidth() * 0.8, 0.0);
        JutsuUtil.particles(level, ParticleTypes.SPLASH, c, 40, target.getBbWidth(), 0.1);
        JutsuUtil.particles(level, ParticleTypes.BUBBLE_POP, c, 20, target.getBbWidth() * 0.6, 0.05);
        JutsuUtil.sound(level, c, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.0f, 0.8f);
        return true;
    }

    public static boolean waterDragon(ServerPlayer p, NinjaData d) {
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.WATER_DRAGON, 1.1f, 0f, dmg(14f));
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.SPLASH, p.position().add(0, 1, 0), 60, 1.0, 0.2);
        JutsuUtil.sound(p.level(), p.getEyePosition(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, 1.5f, 0.5f);
        return true;
    }

    // ================================================================ WIND

    public static boolean galePalm(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : JutsuUtil.inCone(p, 8, 45)) {
            e.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
            JutsuUtil.push(e, look.scale(2.0).add(0, 0.4, 0));
        }
        deflectProjectiles(p, 8, 45);
        JutsuUtil.stream(level, ParticleTypes.CLOUD, eye.add(look), look, 25, 60, 0.6, 1.3);
        JutsuUtil.sound(level, eye, SoundEvents.ENDER_DRAGON_FLAP, 1.0f, 1.4f);
        return true;
    }

    public static boolean vacuumBlade(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 start = p.getEyePosition();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 24);
        Vec3 end = hit.getType() == HitResult.Type.MISS ? start.add(p.getLookAngle().scale(24)) : hit.getLocation();
        AABB box = new AABB(start, end).inflate(1.0);
        for (Entity e : level.getEntities(p, box, cand -> JutsuUtil.isValidTarget(p, cand))) {
            if (e.getBoundingBox().inflate(0.8).clip(start, end).isPresent()) {
                e.hurt(ModDamage.jutsu(level, p, p), dmg(9f));
            }
        }
        JutsuUtil.line(level, ParticleTypes.SWEEP_ATTACK, start.add(p.getLookAngle()), end, 1.5, 1, 0.0);
        JutsuUtil.line(level, ParticleTypes.CLOUD, start.add(p.getLookAngle()), end, 0.75, 1, 0.05);
        JutsuUtil.sound(level, start, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.6f);
        return true;
    }

    public static boolean greatBreakthrough(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : JutsuUtil.inCone(p, 14, 40)) {
            e.hurt(ModDamage.jutsu(level, p, p), dmg(6f));
            JutsuUtil.push(e, look.scale(3.2).add(0, 0.6, 0));
        }
        deflectProjectiles(p, 14, 40);
        if (JutsuUtil.griefing(level, p)) {
            double minDot = Math.cos(Math.toRadians(40));
            BlockPos center = p.blockPosition();
            int broken = 0;
            for (BlockPos mpos : BlockPos.betweenClosed(center.offset(-10, -3, -10), center.offset(10, 6, 10))) {
                if (broken >= 120) break;
                BlockState state = level.getBlockState(mpos);
                if (state.isAir()) continue;
                boolean plant = state.is(BlockTags.LEAVES) || (state.canBeReplaced() && state.getFluidState().isEmpty());
                if (!plant) continue;
                Vec3 to = Vec3.atCenterOf(mpos).subtract(eye);
                double dist = to.length();
                if (dist > 10 || dist < 1e-3 || to.scale(1.0 / dist).dot(look) < minDot) continue;
                level.destroyBlock(mpos.immutable(), true, p);
                broken++;
            }
        }
        JutsuUtil.stream(level, ParticleTypes.CLOUD, eye.add(look), look, 35, 200, 0.9, 2.0);
        JutsuUtil.sound(level, eye, SoundEvents.ENDER_DRAGON_FLAP, 2.0f, 0.6f);
        return true;
    }

    private static void deflectProjectiles(ServerPlayer p, double range, double halfAngle) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double minDot = Math.cos(Math.toRadians(halfAngle));
        for (Projectile proj : p.level().getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(range), pr -> pr.getOwner() != p)) {
            Vec3 to = proj.position().subtract(eye);
            double dist = to.length();
            if (dist > range || (dist > 1e-3 && to.scale(1.0 / dist).dot(look) < minDot)) continue;
            proj.setDeltaMovement(look.scale(1.6));
            proj.setOwner(p);
            proj.hurtMarked = true;
        }
    }

    // ================================================================ LIGHTNING

    public static boolean lightningArmor(ServerPlayer p, NinjaData d) {
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 0));
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.ELECTRIC_SPARK, p.position().add(0, 1, 0), 80, 0.6, 0.3);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.TRIDENT_THUNDER, 0.6f, 1.8f);
        return true;
    }

    public static boolean chidori(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 start = p.position().add(0, 1, 0);
        LivingEntity target = JutsuUtil.rayTarget(p, 16);
        if (target != null) {
            Vec3 dir = target.position().subtract(p.position()).multiply(1, 0, 1);
            if (dir.lengthSqr() < 1e-4) dir = p.getLookAngle().multiply(1, 0, 1);
            dir = dir.normalize();
            Vec3 dest = target.position().subtract(dir.scale(target.getBbWidth() / 2 + 0.9));
            Vec3 safe = JutsuUtil.findSafe(p, dest);
            if (safe != null) JutsuUtil.teleport(p, safe);
            target.hurt(ModDamage.jutsu(level, p, p), dmg(16f));
            JutsuUtil.push(target, dir.scale(1.4).add(0, 0.4, 0));
            JutsuUtil.line(level, ParticleTypes.ELECTRIC_SPARK, start, target.getBoundingBox().getCenter(), 0.4, 3, 0.15);
            JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, target.getBoundingBox().getCenter(), 60, 0.5, 0.4);
            JutsuUtil.particles(level, ParticleTypes.CRIT, target.getBoundingBox().getCenter(), 20, 0.4, 0.3);
        } else {
            Vec3 look = p.getLookAngle();
            JutsuUtil.push(p, new Vec3(look.x * 2.0, Math.max(0.15, look.y * 0.8), look.z * 2.0));
            JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, start, 50, 0.4, 0.3);
        }
        JutsuUtil.sound(level, p.position(), SoundEvents.TRIDENT_THUNDER, 0.7f, 1.6f);
        JutsuUtil.sound(level, p.position(), SoundEvents.LIGHTNING_BOLT_IMPACT, 0.6f, 1.5f);
        return true;
    }

    public static boolean thunderStrike(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 40);
        if (hit.getType() == HitResult.Type.MISS) {
            noTarget(p);
            return false;
        }
        BlockPos pos = hit.getBlockPos().relative(hit.getDirection());
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return false;
        bolt.moveTo(Vec3.atBottomCenterOf(pos));
        bolt.setVisualOnly(true); // we deal our own damage so the caster's allies are spared
        level.addFreshEntity(bolt);
        Vec3 c = Vec3.atBottomCenterOf(pos);
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 4)) {
            e.hurt(ModDamage.jutsu(level, null, p), dmg(12f));
            e.setSecondsOnFire(3);
        }
        if (JutsuUtil.griefing(level, p) && BaseFireBlock.canBePlacedAt(level, pos, Direction.UP)) {
            level.setBlockAndUpdate(pos, BaseFireBlock.getState(level, pos));
        }
        JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, c.add(0, 1, 0), 120, 1.5, 0.5);
        return true;
    }

    // ================================================================ EARTH

    public static boolean earthWall(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Direction facing = p.getDirection();
        Direction side = facing.getClockWise();
        BlockPos origin = p.blockPosition().relative(facing, 3);
        BlockState wall = ModBlocks.EARTH_WALL.get().defaultBlockState();
        boolean replacePlants = JutsuUtil.griefing(level, p);
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.COARSE_DIRT.defaultBlockState());
        int placed = 0;
        for (int w = -2; w <= 2; w++) {
            BlockPos col = origin.relative(side, w);
            for (int i = 0; i < 3 && level.getBlockState(col.below()).canBeReplaced(); i++) col = col.below();
            for (int i = 0; i < 3 && !level.getBlockState(col).canBeReplaced(); i++) col = col.above();
            for (int h = 0; h < 3; h++) {
                BlockPos pos = col.above(h);
                BlockState existing = level.getBlockState(pos);
                boolean free = existing.isAir() || (replacePlants && existing.canBeReplaced() && existing.getFluidState().isEmpty());
                if (!free || !level.getEntitiesOfClass(LivingEntity.class, new AABB(pos)).isEmpty()) continue;
                level.setBlock(pos, wall, 3);
                level.sendParticles(dirt, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 8, 0.4, 0.4, 0.4, 0.1);
                placed++;
            }
        }
        if (placed == 0) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        JutsuUtil.sound(level, Vec3.atCenterOf(origin), SoundEvents.ROOTED_DIRT_PLACE, 1.5f, 0.6f);
        JutsuUtil.sound(level, Vec3.atCenterOf(origin), SoundEvents.STONE_PLACE, 1.5f, 0.5f);
        return true;
    }

    public static boolean rockArmor(ServerPlayer p, NinjaData d) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 400, 1));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 0));
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        JutsuUtil.particles(p.serverLevel(), stone, p.position().add(0, 1, 0), 60, 0.5, 0.1);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.STONE_PLACE, 1.2f, 0.5f);
        return true;
    }

    public static boolean earthSpikes(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 20);
        if (hit.getType() == HitResult.Type.MISS) {
            noTarget(p);
            return false;
        }
        Vec3 c = hit.getLocation();
        for (LivingEntity e : JutsuUtil.inRadius(level, p, c, 5)) {
            e.hurt(ModDamage.jutsu(level, null, p), dmg(10f));
            JutsuUtil.push(e, new Vec3(0, 1.1, 0));
        }
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
        RandomSource r = level.getRandom();
        for (int i = 0; i < 14; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            double dist = r.nextDouble() * 4.5;
            Vec3 base = c.add(Math.cos(a) * dist, 0, Math.sin(a) * dist);
            JutsuUtil.line(level, i % 2 == 0 ? stone : dirt, base, base.add(0, 1.5 + r.nextDouble() * 1.5, 0), 0.3, 3, 0.08);
        }
        JutsuUtil.sound(level, c, SoundEvents.STONE_BREAK, 2.0f, 0.5f);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.6f, 1.6f);
        return true;
    }

    // ================================================================ NON-ELEMENTAL

    public static boolean substitution(ServerPlayer p, NinjaData d) {
        d.setSubstitutionUntil(p.level().getGameTime() + 120);
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.POOF, p.position().add(0, 1, 0), 10, 0.3, 0.02);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ILLUSIONER_PREPARE_MIRROR, 0.8f, 1.2f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.substitution_ready").withStyle(ChatFormatting.LIGHT_PURPLE), true);
        return true;
    }

    /** Called when a primed substitution absorbs a hit: swap with a log and vanish backwards. */
    public static void triggerSubstitution(ServerPlayer p, @Nullable Entity attacker) {
        ServerLevel level = p.serverLevel();
        Vec3 origin = p.position();
        Vec3 away = attacker != null ? origin.subtract(attacker.position()) : p.getLookAngle().scale(-1);
        away = new Vec3(away.x, 0, away.z);
        if (away.lengthSqr() < 1e-4) away = new Vec3(-p.getLookAngle().x, 0, -p.getLookAngle().z);
        if (away.lengthSqr() < 1e-4) away = new Vec3(1, 0, 0);
        away = away.normalize();

        level.sendParticles(ParticleTypes.POOF, origin.x, origin.y + 1, origin.z, 30, 0.4, 0.8, 0.4, 0.02);
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.OAK_LOG.defaultBlockState()),
                origin.x, origin.y + 1, origin.z, 40, 0.3, 0.6, 0.3, 0.1);
        for (double dist = 7; dist >= 2; dist -= 1) {
            Vec3 safe = JutsuUtil.findSafe(p, origin.add(away.scale(dist)));
            if (safe != null) {
                JutsuUtil.teleport(p, safe);
                break;
            }
        }
        level.sendParticles(ParticleTypes.POOF, p.getX(), p.getY() + 1, p.getZ(), 15, 0.3, 0.6, 0.3, 0.02);
        JutsuUtil.sound(level, origin, SoundEvents.WOOD_BREAK, 1.0f, 0.8f);
        JutsuUtil.sound(level, p.position(), SoundEvents.ILLUSIONER_MIRROR_MOVE, 1.0f, 1.2f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.substitution_used").withStyle(ChatFormatting.LIGHT_PURPLE), true);
    }

    public static boolean bodyFlicker(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        BlockHitResult hit = JutsuUtil.rayBlock(p, 16);
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? eye.add(look.scale(16)) : hit.getLocation().subtract(look.scale(0.7));
        Vec3 feet = aim.subtract(0, p.getEyeHeight(), 0);
        Vec3 step = look.scale(-0.5);
        Vec3 safe = null;
        for (int i = 0; i < 32 && safe == null; i++, feet = feet.add(step)) safe = JutsuUtil.findSafe(p, feet);
        if (safe == null || safe.distanceToSqr(p.position()) < 4) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 from = p.position();
        level.sendParticles(ParticleTypes.POOF, from.x, from.y + 1, from.z, 20, 0.3, 0.6, 0.3, 0.02);
        JutsuUtil.teleport(p, safe);
        level.sendParticles(ParticleTypes.POOF, safe.x, safe.y + 1, safe.z, 20, 0.3, 0.6, 0.3, 0.02);
        level.sendParticles(ParticleTypes.CHERRY_LEAVES, safe.x, safe.y + 1, safe.z, 12, 0.6, 0.6, 0.6, 0.0);
        JutsuUtil.sound(level, from, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.6f);
        JutsuUtil.sound(level, safe, SoundEvents.PLAYER_ATTACK_SWEEP, 0.8f, 1.8f);
        return true;
    }

    public static boolean shadowClone(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        // Only one batch of clones at a time.
        for (ShadowClone old : level.getEntitiesOfClass(ShadowClone.class, p.getBoundingBox().inflate(96),
                c -> p.getUUID().equals(c.getOwnerUUID()))) {
            old.poof();
        }
        int count = d.getClan() == Clan.UZUMAKI ? 4 : 2;
        Vec3 right = JutsuUtil.right(p);
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            double offset = (i % 2 == 0 ? 1 : -1) * (1.5 + (i / 2) * 1.5);
            Vec3 pos = p.position().add(right.scale(offset));
            ShadowClone clone = ModEntities.SHADOW_CLONE.get().create(level);
            if (clone == null) continue;
            clone.moveTo(pos.x, p.getY(), pos.z, p.getYRot(), p.getXRot());
            if (!level.noCollision(clone)) clone.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot());
            clone.setYHeadRot(p.getYHeadRot());
            clone.setOwner(p);
            clone.copyEquipment(p);
            long rasengan = d.getRasenganUntil() - p.level().getGameTime();
            if (rasengan > 0) clone.giveHandJutsu(ShadowClone.HandJutsu.RASENGAN, (int) rasengan); // a Rasengan already in hand
            level.addFreshEntity(clone);
            level.sendParticles(ParticleTypes.POOF, clone.getX(), clone.getY() + 1, clone.getZ(), 25, 0.3, 0.7, 0.3, 0.03);
            spawned++;
        }
        if (spawned == 0) return false;
        JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 0.8f, 1.6f);
        return true;
    }

    public static boolean rasengan(ServerPlayer p, NinjaData d) {
        d.setRasenganUntil(p.level().getGameTime() + 200);
        JutsuUtil.particles(p.serverLevel(), CHAKRA_DUST, p.getEyePosition().add(p.getLookAngle().scale(0.6)), 30, 0.2, 0.0);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.8f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.rasengan_ready").withStyle(ChatFormatting.AQUA), true);
        return true;
    }

    /** Called from the melee-hit event when a charged Rasengan connects (also used by shadow clones). */
    public static void rasenganHit(LivingEntity p, LivingEntity target) {
        ServerLevel level = (ServerLevel) p.level();
        Vec3 dir = target.position().subtract(p.position()).multiply(1, 0, 1);
        dir = dir.lengthSqr() < 1e-4 ? p.getLookAngle() : dir.normalize();
        JutsuUtil.push(target, dir.scale(2.2).add(0, 0.6, 0));
        Vec3 c = target.getBoundingBox().getCenter();
        level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        JutsuUtil.particles(level, CHAKRA_DUST, c, 60, 0.6, 0.0);
        JutsuUtil.stream(level, ParticleTypes.CLOUD, c, dir, 50, 30, 0.2, 0.6);
        JutsuUtil.sound(level, c, SoundEvents.GENERIC_EXPLODE, 0.8f, 1.4f);
    }

    /** Wind Release: Rasenshuriken - a spinning shuriken of wind chakra that bursts into a sphere of blades. */
    public static boolean rasenshuriken(ServerPlayer p, NinjaData d) {
        JutsuProjectile.shoot(p, JutsuProjectile.Kind.RASENSHURIKEN, 1.0f, 0f, dmg(20f));
        JutsuUtil.particles(p.serverLevel(), ParticleTypes.SWEEP_ATTACK, p.getEyePosition().add(p.getLookAngle().scale(1.0)), 6, 0.4, 0.0);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ELYTRA_FLYING, 1.0f, 1.8f);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.4f);
        return true;
    }

    // ================================================================ CLAN

    public static boolean shadowPossession(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 24);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int duration = Math.round(120 * d.genjutsuMultiplier());
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 6));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 2));
        if (target instanceof Mob mob) {
            mob.getNavigation().stop();
            mob.setTarget(null);
        }
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 1));
        JutsuUtil.line(level, SHADOW_DUST, p.position().add(0, 0.1, 0), target.position().add(0, 0.1, 0), 0.3, 2, 0.08);
        JutsuUtil.particles(level, ParticleTypes.SQUID_INK, target.position().add(0, 0.3, 0), 30, 0.4, 0.02);
        JutsuUtil.sound(level, target.position(), SoundEvents.SOUL_ESCAPE, 1.5f, 0.6f);
        return true;
    }

    public static boolean palmRotation(ServerPlayer p, NinjaData d) {
        d.setRotationUntil(p.level().getGameTime() + 30);
        for (LivingEntity e : JutsuUtil.inRadius(p.level(), p, p.position().add(0, 1, 0), 5)) {
            e.hurt(ModDamage.jutsu(p.level(), p, p), dmg(5f));
        }
        rotationTick(p);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDER_DRAGON_FLAP, 1.5f, 1.2f);
        return true;
    }

    /** Runs every tick while Palm Rotation is spinning. */
    public static void rotationTick(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        if (p.tickCount % 2 == 0) {
            for (LivingEntity e : JutsuUtil.inRadius(level, p, c.add(0, 1, 0), 4.5)) {
                Vec3 dir = e.position().subtract(c).multiply(1, 0, 1);
                dir = dir.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : dir.normalize();
                JutsuUtil.push(e, dir.scale(1.2).add(0, 0.35, 0));
            }
            List<Projectile> incoming = level.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(5), pr -> pr.getOwner() != p);
            for (Projectile proj : incoming) {
                level.sendParticles(ParticleTypes.CRIT, proj.getX(), proj.getY(), proj.getZ(), 5, 0.1, 0.1, 0.1, 0.1);
                proj.discard();
            }
        }
        double angle = (p.tickCount % 20) / 20.0 * Math.PI * 2;
        for (int i = 0; i < 8; i++) {
            double a = angle + i * Math.PI / 4;
            double y = c.y + 0.1 + (i % 4) * 0.5;
            level.sendParticles(ParticleTypes.CLOUD, c.x + Math.cos(a) * 1.6, y, c.z + Math.sin(a) * 1.6, 1, 0, 0, 0, 0);
            level.sendParticles(CHAKRA_DUST, c.x + Math.cos(a + 0.4) * 1.3, y + 0.25, c.z + Math.sin(a + 0.4) * 1.3, 1, 0, 0, 0, 0);
        }
    }

    public static boolean amaterasu(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 30);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int amplifier = Math.min(3, d.stat(Stat.GENJUTSU) / 25);
        target.addEffect(new MobEffectInstance(ModEffects.AMATERASU.get(), Math.round(200 * d.genjutsuMultiplier()), amplifier));
        target.hurt(ModDamage.jutsu(level, p, p), dmg(4f));
        JutsuUtil.particles(level, BLACK_FLAME, target.getBoundingBox().getCenter(), 80, target.getBbWidth() * 0.6, 0.0);
        // The strain on the eyes:
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
        p.hurt(p.damageSources().magic(), 2.0f);
        JutsuUtil.sound(level, target.position(), SoundEvents.FIRECHARGE_USE, 1.0f, 0.4f);
        return true;
    }

    // ================================================================ YIN (illusions, scale with Genjutsu)

    public static boolean hellViewing(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, 20);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int duration = Math.round(120 * d.genjutsuMultiplier());
        applyIllusion(target, duration);
        target.hurt(ModDamage.jutsu(level, p, p), dmg(2f));
        JutsuUtil.particles(level, YIN_DUST, target.getEyePosition(), 50, 0.5, 0.0);
        JutsuUtil.particles(level, ParticleTypes.SQUID_INK, target.getEyePosition(), 15, 0.3, 0.02);
        JutsuUtil.sound(level, target.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.6f, 1.4f);
        return true;
    }

    public static boolean mindFog(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        List<LivingEntity> targets = JutsuUtil.inRadius(level, p, p.position().add(0, 1, 0), 7);
        if (targets.isEmpty()) {
            noTarget(p);
            return false;
        }
        int duration = Math.round(100 * d.genjutsuMultiplier());
        for (LivingEntity e : targets) applyIllusion(e, duration);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3;
            JutsuUtil.particles(level, YIN_DUST, p.position().add(Math.cos(a) * 3.5, 1.0, Math.sin(a) * 3.5), 25, 1.2, 0.0);
        }
        JutsuUtil.particles(level, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 60, 3.0, 0.02);
        JutsuUtil.sound(level, p.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.8f, 0.8f);
        return true;
    }

    /** Players see darkness and swaying vision; mobs lose track of their target and stumble. */
    private static void applyIllusion(LivingEntity target, int duration) {
        if (target instanceof net.minecraft.world.entity.player.Player) {
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, duration + 40, 0));
            target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, duration, 0));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 1));
        } else {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 3));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 2));
            if (target instanceof Mob mob) {
                mob.setTarget(null);
                mob.getNavigation().stop();
            }
        }
    }

    // ================================================================ YANG (vitality, scales with Medical)

    public static boolean mysticalPalm(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        float amount = 6f + d.stat(Stat.MEDICAL) * 0.25f;
        LivingEntity patient = p;
        // Heal the player you're looking at (within 5 blocks) instead of yourself, if any.
        Vec3 eye = p.getEyePosition();
        for (net.minecraft.world.entity.player.Player other : level.getEntitiesOfClass(net.minecraft.world.entity.player.Player.class,
                p.getBoundingBox().inflate(5), o -> o != p && o.isAlive())) {
            Vec3 to = other.getBoundingBox().getCenter().subtract(eye);
            if (to.length() <= 5 && to.normalize().dot(p.getLookAngle()) > 0.95 && p.hasLineOfSight(other)) {
                patient = other;
                break;
            }
        }
        if (patient.getHealth() >= patient.getMaxHealth()) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.full_health").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        patient.heal(amount);
        JutsuUtil.particles(level, YANG_DUST, patient.getBoundingBox().getCenter(), 40, 0.5, 0.0);
        JutsuUtil.particles(level, ParticleTypes.HEART, patient.getEyePosition(), 4, 0.4, 0.0);
        JutsuUtil.sound(level, patient.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.2f, 1.2f);
        return true;
    }

    public static boolean vitalitySurge(ServerPlayer p, NinjaData d) {
        int bonus = d.stat(Stat.MEDICAL) * 4;
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200 + bonus, 1));
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 400 + bonus, 1));
        p.removeEffect(MobEffects.POISON);
        p.removeEffect(MobEffects.WITHER);
        p.removeEffect(MobEffects.HUNGER);
        ServerLevel level = p.serverLevel();
        JutsuUtil.particles(level, YANG_DUST, p.position().add(0, 1, 0), 80, 0.7, 0.0);
        JutsuUtil.particles(level, ParticleTypes.HAPPY_VILLAGER, p.position().add(0, 1, 0), 20, 0.6, 0.0);
        JutsuUtil.sound(level, p.position(), SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.4f);
        return true;
    }
}
