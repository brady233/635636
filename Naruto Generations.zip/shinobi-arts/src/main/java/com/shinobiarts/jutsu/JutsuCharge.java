package com.shinobiarts.jutsu;

import com.shinobiarts.Config;

/**
 * Hold-to-charge casting. Holding right-click with a release charges its selected jutsu (like drawing a bow);
 * letting go casts it. A quick tap casts at {@code chargeMinPower} of its damage and a full charge at
 * {@code chargeMaxPower}; how long a full charge takes depends on the jutsu's rank. Only jutsu that deal damage
 * charge: utility jutsu (Substitution, armors, walls, healing...) still go off the moment you right-click.
 * Shared by the server (the cast) and the client (the charge counter on screen).
 */
public final class JutsuCharge {
    private JutsuCharge() {}

    public static boolean chargeable(Jutsu jutsu) {
        return Config.b(Config.CHARGE_ENABLED) && Jutsus.upgradeable(jutsu);
    }

    /** Ticks for a full charge: longer for stronger ranks (0.5 s for D up to 2.5 s for S by default). */
    public static int fullChargeTicks(Jutsu jutsu) {
        int ticks = switch (jutsu.rank()) {
            case D -> Config.i(Config.CHARGE_TICKS_D);
            case C -> Config.i(Config.CHARGE_TICKS_C);
            case B -> Config.i(Config.CHARGE_TICKS_B);
            case A -> Config.i(Config.CHARGE_TICKS_A);
            case S -> Config.i(Config.CHARGE_TICKS_S);
        };
        return Math.max(1, ticks);
    }

    /** 0..1: how charged the jutsu is after holding for {@code ticks}. */
    public static float fraction(Jutsu jutsu, int ticks) {
        return Math.min(1f, Math.max(0f, ticks / (float) fullChargeTicks(jutsu)));
    }

    /** Damage multiplier for a charge: chargeMinPower at a tap, chargeMaxPower at full. */
    public static float power(Jutsu jutsu, int ticks) {
        float min = Config.f(Config.CHARGE_MIN_POWER), max = Math.max(min, Config.f(Config.CHARGE_MAX_POWER));
        return min + (max - min) * fraction(jutsu, ticks);
    }
}
