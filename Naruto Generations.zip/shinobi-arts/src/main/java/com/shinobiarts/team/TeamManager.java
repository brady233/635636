package com.shinobiarts.team;

import com.shinobiarts.Config;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Teams of up to 4 players (configurable), saved with the world. One team per player; the leader invites
 * and kicks, and leadership passes on if the leader leaves. Members see their team in the stats menu (J).
 */
public final class TeamManager extends SavedData {
    private static final String DATA_NAME = "shinobiarts_teams";
    private static final long INVITE_MILLIS = 120_000L;

    public static final class Team {
        public final String name;
        public UUID leader;
        /** Members in join order (leader included), with their last known names. */
        public final LinkedHashMap<UUID, String> members = new LinkedHashMap<>();

        Team(String name, UUID leader) {
            this.name = name;
            this.leader = leader;
        }
    }

    private record Invite(String teamKey, long expires) {}

    private final Map<String, Team> teams = new LinkedHashMap<>();
    private final Map<UUID, String> memberOf = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();

    public static TeamManager get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TeamManager::load, TeamManager::new, DATA_NAME);
    }

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    @Nullable
    public Team teamOf(UUID player) {
        String k = memberOf.get(player);
        return k == null ? null : teams.get(k);
    }

    // ---------------------------------------------------------------- actions (each returns a message for the player)

    public Component create(ServerPlayer player, String name) {
        if (teamOf(player.getUUID()) != null) return fail("message.shinobiarts.team_already_in");
        if (!name.matches("[A-Za-z0-9_]{2,16}")) return fail("message.shinobiarts.team_bad_name");
        if (teams.containsKey(key(name))) return fail("message.shinobiarts.team_name_taken", name);
        Team team = new Team(name, player.getUUID());
        team.members.put(player.getUUID(), player.getGameProfile().getName());
        teams.put(key(name), team);
        memberOf.put(player.getUUID(), key(name));
        setDirty();
        syncTeam(player.server, team, null);
        return ok("message.shinobiarts.team_created", name);
    }

    public Component invite(ServerPlayer leader, ServerPlayer target) {
        Team team = teamOf(leader.getUUID());
        if (team == null) return fail("message.shinobiarts.team_none");
        if (!team.leader.equals(leader.getUUID())) return fail("message.shinobiarts.team_not_leader");
        if (target == leader) return fail("message.shinobiarts.team_invite_self");
        if (teamOf(target.getUUID()) != null) return fail("message.shinobiarts.team_target_in_team", target.getGameProfile().getName());
        if (team.members.size() >= Config.i(Config.TEAM_MAX)) return fail("message.shinobiarts.team_full", Config.i(Config.TEAM_MAX));
        invites.put(target.getUUID(), new Invite(key(team.name), System.currentTimeMillis() + INVITE_MILLIS));
        Style accept = Style.EMPTY.withColor(ChatFormatting.GREEN).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/team accept"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("/team accept")));
        Style decline = Style.EMPTY.withColor(ChatFormatting.RED).withBold(true)
                .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/team decline"))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("/team decline")));
        target.sendSystemMessage(Component.translatable("message.shinobiarts.team_invited", leader.getGameProfile().getName(), team.name)
                .withStyle(ChatFormatting.AQUA)
                .append(Component.literal("  "))
                .append(Component.translatable("message.shinobiarts.team_accept_button").withStyle(accept))
                .append(Component.literal("  "))
                .append(Component.translatable("message.shinobiarts.team_decline_button").withStyle(decline)));
        syncPlayer(target);
        return ok("message.shinobiarts.team_invite_sent", target.getGameProfile().getName());
    }

    public Component accept(ServerPlayer player) {
        Invite invite = invites.remove(player.getUUID());
        if (invite == null || invite.expires() < System.currentTimeMillis()) return fail("message.shinobiarts.team_no_invite");
        Team team = teams.get(invite.teamKey());
        if (team == null) return fail("message.shinobiarts.team_no_invite");
        if (teamOf(player.getUUID()) != null) return fail("message.shinobiarts.team_already_in");
        if (team.members.size() >= Config.i(Config.TEAM_MAX)) return fail("message.shinobiarts.team_full", Config.i(Config.TEAM_MAX));
        team.members.put(player.getUUID(), player.getGameProfile().getName());
        memberOf.put(player.getUUID(), invite.teamKey());
        setDirty();
        broadcast(player.server, team, Component.translatable("message.shinobiarts.team_joined", player.getGameProfile().getName(), team.name)
                .withStyle(ChatFormatting.GREEN));
        syncTeam(player.server, team, null);
        return Component.empty();
    }

    public Component decline(ServerPlayer player) {
        if (invites.remove(player.getUUID()) == null) return fail("message.shinobiarts.team_no_invite");
        syncPlayer(player);
        return ok("message.shinobiarts.team_declined");
    }

    public Component leave(ServerPlayer player) {
        Team team = teamOf(player.getUUID());
        if (team == null) return fail("message.shinobiarts.team_none");
        removeMember(player.server, team, player.getUUID());
        broadcast(player.server, team, Component.translatable("message.shinobiarts.team_left", player.getGameProfile().getName())
                .withStyle(ChatFormatting.YELLOW));
        syncPlayer(player);
        return ok("message.shinobiarts.team_you_left", team.name);
    }

    public Component kick(ServerPlayer leader, String name) {
        Team team = teamOf(leader.getUUID());
        if (team == null) return fail("message.shinobiarts.team_none");
        if (!team.leader.equals(leader.getUUID())) return fail("message.shinobiarts.team_not_leader");
        UUID target = null;
        for (Map.Entry<UUID, String> e : team.members.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) target = e.getKey();
        }
        if (target == null || target.equals(leader.getUUID())) return fail("message.shinobiarts.team_no_member", name);
        removeMember(leader.server, team, target);
        ServerPlayer kicked = leader.server.getPlayerList().getPlayer(target);
        if (kicked != null) {
            kicked.sendSystemMessage(Component.translatable("message.shinobiarts.team_kicked", team.name).withStyle(ChatFormatting.RED));
            syncPlayer(kicked);
        }
        broadcast(leader.server, team, Component.translatable("message.shinobiarts.team_left", name).withStyle(ChatFormatting.YELLOW));
        return Component.empty();
    }

    public Component disband(ServerPlayer leader) {
        Team team = teamOf(leader.getUUID());
        if (team == null) return fail("message.shinobiarts.team_none");
        if (!team.leader.equals(leader.getUUID())) return fail("message.shinobiarts.team_not_leader");
        List<UUID> members = new ArrayList<>(team.members.keySet());
        broadcast(leader.server, team, Component.translatable("message.shinobiarts.team_disbanded", team.name).withStyle(ChatFormatting.RED));
        teams.remove(key(team.name));
        for (UUID m : members) {
            memberOf.remove(m);
            ServerPlayer p = leader.server.getPlayerList().getPlayer(m);
            if (p != null) syncPlayer(p);
        }
        setDirty();
        return Component.empty();
    }

    public Component info(ServerPlayer player) {
        Team team = teamOf(player.getUUID());
        if (team == null) return fail("message.shinobiarts.team_none");
        MutableComponent msg = Component.translatable("message.shinobiarts.team_info", team.name, team.members.size(), Config.i(Config.TEAM_MAX))
                .withStyle(ChatFormatting.AQUA);
        for (Map.Entry<UUID, String> e : team.members.entrySet()) {
            boolean online = player.server.getPlayerList().getPlayer(e.getKey()) != null;
            msg.append(Component.literal("\n " + (online ? "● " : "○ ")).withStyle(online ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY))
                    .append(Component.literal(e.getValue() + (e.getKey().equals(team.leader) ? " ★" : "")).withStyle(ChatFormatting.WHITE));
        }
        return msg;
    }

    private void removeMember(MinecraftServer server, Team team, UUID member) {
        team.members.remove(member);
        memberOf.remove(member);
        if (team.members.isEmpty()) {
            teams.remove(key(team.name));
        } else if (team.leader.equals(member)) {
            team.leader = team.members.keySet().iterator().next();
            broadcast(server, team, Component.translatable("message.shinobiarts.team_new_leader", team.members.get(team.leader))
                    .withStyle(ChatFormatting.YELLOW));
        }
        setDirty();
        syncTeam(server, team, null);
    }

    // ---------------------------------------------------------------- login / logout / sync

    /** Keeps names fresh and updates teammates' online lists. */
    public void onLogin(ServerPlayer player) {
        Team team = teamOf(player.getUUID());
        if (team == null) return;
        team.members.put(player.getUUID(), player.getGameProfile().getName());
        setDirty();
        syncTeam(player.server, team, null);
    }

    public void onLogout(ServerPlayer player) {
        invites.remove(player.getUUID());
        Team team = teamOf(player.getUUID());
        if (team != null) syncTeam(player.server, team, player.getUUID());
    }

    private void syncTeam(MinecraftServer server, Team team, @Nullable UUID leaving) {
        for (UUID m : team.members.keySet()) {
            if (m.equals(leaving)) continue;
            ServerPlayer p = server.getPlayerList().getPlayer(m);
            if (p != null) syncPlayer(p);
        }
    }

    private static void syncPlayer(ServerPlayer player) {
        ModNetwork.sync(player);
    }

    /** What the player's stats menu shows: their team, its members and who's online, or a pending invite. */
    public CompoundTag clientInfo(ServerPlayer player) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("Max", Config.i(Config.TEAM_MAX));
        Team team = teamOf(player.getUUID());
        if (team != null) {
            tag.putString("Name", team.name);
            ListTag list = new ListTag();
            for (Map.Entry<UUID, String> e : team.members.entrySet()) {
                CompoundTag m = new CompoundTag();
                m.putString("Name", e.getValue());
                m.putBoolean("Online", player.server.getPlayerList().getPlayer(e.getKey()) != null);
                m.putBoolean("Leader", e.getKey().equals(team.leader));
                list.add(m);
            }
            tag.put("Members", list);
        } else {
            Invite invite = invites.get(player.getUUID());
            Team invited = invite == null || invite.expires() < System.currentTimeMillis() ? null : teams.get(invite.teamKey());
            if (invited != null) tag.putString("Invite", invited.name);
        }
        return tag;
    }

    private void broadcast(MinecraftServer server, Team team, Component message) {
        for (UUID m : team.members.keySet()) {
            ServerPlayer p = server.getPlayerList().getPlayer(m);
            if (p != null) p.sendSystemMessage(message);
        }
    }

    private static Component ok(String key, Object... args) {
        return Component.translatable(key, args).withStyle(ChatFormatting.GREEN);
    }

    private static Component fail(String key, Object... args) {
        return Component.translatable(key, args).withStyle(ChatFormatting.RED);
    }

    // ---------------------------------------------------------------- saving

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Team team : teams.values()) {
            CompoundTag t = new CompoundTag();
            t.putString("Name", team.name);
            t.putUUID("Leader", team.leader);
            ListTag members = new ListTag();
            for (Map.Entry<UUID, String> e : team.members.entrySet()) {
                CompoundTag m = new CompoundTag();
                m.putUUID("Id", e.getKey());
                m.putString("Name", e.getValue());
                members.add(m);
            }
            t.put("Members", members);
            list.add(t);
        }
        tag.put("Teams", list);
        return tag;
    }

    private static TeamManager load(CompoundTag tag) {
        TeamManager manager = new TeamManager();
        for (Tag t : tag.getList("Teams", Tag.TAG_COMPOUND)) {
            CompoundTag ct = (CompoundTag) t;
            if (!ct.hasUUID("Leader")) continue;
            Team team = new Team(ct.getString("Name"), ct.getUUID("Leader"));
            for (Tag mt : ct.getList("Members", Tag.TAG_COMPOUND)) {
                CompoundTag m = (CompoundTag) mt;
                if (m.hasUUID("Id")) team.members.put(m.getUUID("Id"), m.getString("Name"));
            }
            if (team.members.isEmpty()) continue;
            if (!team.members.containsKey(team.leader)) team.leader = team.members.keySet().iterator().next();
            manager.teams.put(key(team.name), team);
            for (UUID m : team.members.keySet()) manager.memberOf.put(m, key(team.name));
        }
        return manager;
    }
}
