package com.shinobiarts.client;

import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/** "Are you sure?" before a stat reset, showing the price and your balance. */
public class ResetConfirmScreen extends Screen {
    private final Screen parent;
    private Button confirm;

    public ResetConfirmScreen(Screen parent) {
        super(Component.translatable("screen.shinobiarts.reset_title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 + 20;
        confirm = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.reset_confirm").withStyle(ChatFormatting.RED), b -> {
            ModNetwork.toServer(new ActionPacket(ActionPacket.RESET_STATS));
            this.minecraft.setScreen(parent);
        }).bounds(cx - 105, y, 100, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, b -> this.minecraft.setScreen(parent))
                .bounds(cx + 5, y, 100, 20).build());
    }

    @Override
    public void tick() {
        NinjaData d = ClientNinjaData.get();
        confirm.active = d.getRyo() >= d.resetCost() && d.allocatedPoints() > 0;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        NinjaData d = ClientNinjaData.get();
        int cx = this.width / 2;
        int y = this.height / 2 - 40;
        g.drawCenteredString(this.font, this.title, cx, y, 0xFFFFFF);
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.reset_text", d.allocatedPoints()), cx, y + 18, 0xDDDDDD);
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.reset_price",
                PlayerDataManager.formatRyo(d.resetCost())), cx, y + 32, 0xF2C230);
        boolean canAfford = d.getRyo() >= d.resetCost();
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.reset_balance",
                PlayerDataManager.formatRyo(d.getRyo())), cx, y + 44, canAfford ? 0x7ED957 : 0xFF6B6B);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }
}
