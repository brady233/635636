package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        for (KeyMapping key : KeyBinds.ALL) event.register(key);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "shinobi_hud", ShinobiHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "combat_tag", CombatHud.OVERLAY);
        event.registerAbove(VanillaGuiOverlay.CROSSHAIR.id(), "jutsu_charge", ChargeHud.OVERLAY);
        event.registerAboveAll("sharingan_flash", SharinganFlash.OVERLAY);
    }

    /** Sharingan eyes on players' faces while their Sharingan is on. */
    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (String skin : event.getSkins()) {
            PlayerRenderer renderer = event.getSkin(skin);
            if (renderer != null) renderer.addLayer(new SharinganEyesLayer<>(renderer, event.getEntityModels()));
        }
        // The Sharingan helmet shows the wearer's own stage when their eyes are on (3 tomoe otherwise).
        com.shinobiarts.item.SharinganItem.clientStage = ClientEyes::stage;
    }

    /** The Sharingan helmet's model: just the head, sitting right over the skin's hat layer, so the eyes hug the face. */
    public static final ModelLayerLocation SHARINGAN_LAYER = new ModelLayerLocation(new ResourceLocation(ShinobiArts.MODID, "sharingan"), "main");

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(SHARINGAN_LAYER, () -> LayerDefinition.create(HumanoidModel.createMesh(new CubeDeformation(0.6F), 0.0F), 64, 32));
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.JUTSU_PROJECTILE.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.THROWN_TOOL.get(), ThrownToolRenderer::new);
        event.registerEntityRenderer(ModEntities.EXPLOSIVE_TAG.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.SHADOW_CLONE.get(), ShadowCloneRenderer::new);
        event.registerEntityRenderer(ModEntities.NINJA_BANDIT.get(), NinjaBanditRenderer::new);
    }
}
