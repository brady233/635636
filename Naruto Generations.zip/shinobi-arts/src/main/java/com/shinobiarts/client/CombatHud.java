package com.shinobiarts.client;

import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** "In Combat (60) - Username" at the top of the screen while you're combat-tagged. */
public final class CombatHud {
    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width);

    private CombatHud() {}

    private static void render(GuiGraphics g, int width) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.level == null) return;
        NinjaData d = ClientNinjaData.get();
        long now = mc.level.getGameTime();
        if (!d.isInCombat(now)) return;
        long seconds = (d.getCombatUntil() - now + 19) / 20;
        Component text = Component.translatable("hud.shinobiarts.combat", seconds, d.getCombatWith());
        int w = mc.font.width(text);
        int x = (width - w) / 2, y = 26;
        boolean flash = seconds <= 5 && (now / 10) % 2 == 0;
        g.fill(x - 6, y - 4, x + w + 6, y + 12, 0xB0200000);
        g.fill(x - 6, y - 4, x + w + 6, y - 3, flash ? 0xFFFFFFFF : 0xFFE03030);
        g.fill(x - 6, y + 11, x + w + 6, y + 12, 0xFF801010);
        g.drawString(mc.font, text, x, y, flash ? 0xFFFFFFFF : 0xFFFF5555, true);
    }
}
