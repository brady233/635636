package com.shinobiarts.client;

import net.minecraft.client.Minecraft;

/** Client-only entry points that common code may call through DistExecutor. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openWallet() {
        Minecraft.getInstance().setScreen(new WalletScreen());
    }

    public static void openStats() {
        Minecraft.getInstance().setScreen(new StatScreen());
    }

    /** Opens or refreshes the quest board / Kage menu with data from the server. */
    public static void openBoard(net.minecraft.nbt.CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if ("kage".equals(tag.getString("Screen"))) {
            if (mc.screen instanceof KageScreen kage) kage.update(tag);
            else mc.setScreen(new KageScreen(tag));
        } else {
            if (mc.screen instanceof QuestBoardScreen board) board.update(tag);
            else mc.setScreen(new QuestBoardScreen(tag));
        }
    }

    /**
     * Applies a data sync from the server, and flashes the Sharingan across the screen when the eyes are
     * switched on or evolve (not on the first sync after joining).
     */
    public static void applySync(net.minecraft.nbt.CompoundTag tag) {
        com.shinobiarts.ninja.NinjaData before = ClientNinjaData.get();
        boolean known = before.isInitialized();
        boolean wasOn = before.isSharinganActive();
        int oldStage = before.getSharinganStage();
        ClientNinjaData.apply(tag);
        com.shinobiarts.ninja.NinjaData now = ClientNinjaData.get();
        if (!known || now.getSharinganStage() <= 0) return;
        if ((now.isSharinganActive() && !wasOn) || now.getSharinganStage() > oldStage) {
            SharinganFlash.play(now.getSharinganStage());
        }
    }
}
