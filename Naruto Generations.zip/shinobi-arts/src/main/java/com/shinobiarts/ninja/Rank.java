package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import javax.annotation.Nullable;

/**
 * Ninja ranks. Each rank has a level cap: a Genin can't level past 75 until they're promoted.
 * Promotions come from a Kage (village system) or the /shinobi rank command.
 */
public enum Rank {
    GENIN("genin", ChatFormatting.GREEN),
    CHUNIN("chunin", ChatFormatting.AQUA),
    JONIN("jonin", ChatFormatting.BLUE),
    ANBU("anbu", ChatFormatting.DARK_GRAY),
    SANNIN("sannin", ChatFormatting.GOLD);

    private final String id;
    private final ChatFormatting color;

    Rank(String id, ChatFormatting color) {
        this.id = id;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    /** Highest level reachable at this rank. */
    public int levelCap() {
        return switch (this) {
            case GENIN -> Config.i(Config.GENIN_LEVEL_CAP);
            case CHUNIN -> Config.i(Config.CHUNIN_LEVEL_CAP);
            case JONIN -> Config.i(Config.JONIN_LEVEL_CAP);
            case ANBU -> Config.i(Config.ANBU_LEVEL_CAP);
            case SANNIN -> Config.i(Config.SANNIN_LEVEL_CAP);
        };
    }

    @Nullable
    public Rank next() {
        int i = ordinal() + 1;
        return i < values().length ? values()[i] : null;
    }

    public MutableComponent displayName() {
        return Component.translatable("rank.shinobiarts." + id).withStyle(color);
    }

    @Nullable
    public static Rank byId(String id) {
        for (Rank r : values()) {
            if (r.id.equals(id)) return r;
        }
        return null;
    }
}
