package com.shinobiarts.item;

import com.shinobiarts.ShinobiArts;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

import javax.annotation.Nullable;
import java.util.List;
import java.util.function.Consumer;

/**
 * Sharingan eyes, worn in the helmet slot: the wearer's face shows the red Sharingan.
 * The eyes are a high-resolution overlay (textures/models/armor/sharingan.png) drawn on a head model
 * that hugs the face, set up in {@code client/SharinganArmorModel}.
 */
public class SharinganItem extends ArmorItem {
    public static final ArmorMaterial MATERIAL = new ArmorMaterial() {
        @Override
        public int getDurabilityForType(Type type) {
            return 165;
        }

        @Override
        public int getDefenseForType(Type type) {
            return 1;
        }

        @Override
        public int getEnchantmentValue() {
            return 15;
        }

        @Override
        public SoundEvent getEquipSound() {
            return SoundEvents.ARMOR_EQUIP_GENERIC;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(Items.ENDER_EYE);
        }

        @Override
        public String getName() {
            return ShinobiArts.MODID + ":sharingan";
        }

        @Override
        public float getToughness() {
            return 0f;
        }

        @Override
        public float getKnockbackResistance() {
            return 0f;
        }
    };

    private static final String TEXTURE = ShinobiArts.MODID + ":textures/models/armor/sharingan.png";
    /** Set on the client: the Sharingan stage an entity's eyes show right now (0 = off). */
    public static java.util.function.ToIntFunction<Entity> clientStage = e -> 0;

    public SharinganItem(Properties properties) {
        super(MATERIAL, Type.HELMET, properties);
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        int stage = entity == null ? 0 : clientStage.applyAsInt(entity);
        return stage > 0 ? ShinobiArts.MODID + ":textures/models/eyes/sharingan_" + stage + ".png" : TEXTURE;
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(com.shinobiarts.client.SharinganArmorModel.INSTANCE);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.sharingan").withStyle(ChatFormatting.DARK_RED));
    }
}
