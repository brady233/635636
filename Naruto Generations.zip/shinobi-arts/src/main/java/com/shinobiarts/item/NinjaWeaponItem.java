package com.shinobiarts.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.shinobiarts.Config;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeMod;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * The named ninja weapons (Kubikiribocho, Samehada, Kusanagi, ...). They are swords, so Kenjutsu points
 * boost them. Attack damage comes from the server config ("weapons" section), so admins can rebalance
 * without a new jar; the tooltip always shows the live value. Big weapons also reach further.
 */
public class NinjaWeaponItem extends SwordItem {
    /** The special effect each weapon has on hit. */
    public enum Ability {
        NONE,
        /** Kubikiribocho: repairs itself a little with every hit. */
        SELF_REPAIR,
        /** Samehada: eats the target's chakra and feeds it to the wielder. */
        CHAKRA_DRAIN,
        /** Kusanagi: Chidori Flow. Spends a little chakra to paralyse the target. */
        CHIDORI_FLOW,
        /** Hidan's scythe: Jashin's ritual heals the wielder for part of the damage (handled in WeaponEvents). */
        LIFESTEAL,
        /** Sword of Fire: sets the target ablaze. */
        BURN,
        /** Shakujo: heavy staff strikes knock targets far back. */
        KNOCKBACK
    }

    private static final UUID REACH_UUID = UUID.fromString("5b1f3c2e-8a4d-4f6e-9c1b-2d7e8f9a0b31");

    private final ForgeConfigSpec.DoubleValue damage;
    private final float attackSpeed;
    private final double reach;
    private final Ability ability;
    private volatile Modifiers cache;

    private record Modifiers(double damage, Multimap<Attribute, AttributeModifier> map) {}

    /**
     * @param damage      config value holding the total attack damage shown on the tooltip
     * @param attackSpeed attacks per second minus 4 (vanilla convention: -2.4 = sword speed 1.6)
     * @param reach       extra attack reach in blocks
     */
    public NinjaWeaponItem(Tier tier, ForgeConfigSpec.DoubleValue damage, float attackSpeed, double reach, Ability ability,
                           Properties properties) {
        super(tier, Math.max(0, (int) Math.round(damage.getDefault() - 1 - tier.getAttackDamageBonus())), attackSpeed, properties);
        this.damage = damage;
        this.attackSpeed = attackSpeed;
        this.reach = reach;
        this.ability = ability;
    }

    public Ability ability() {
        return ability;
    }

    /** Total attack damage (including the player's base 1), as set in the config. */
    public double attackDamage() {
        return Config.d(damage);
    }

    @Override
    public float getDamage() {
        return (float) attackDamage() - 1f;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot != EquipmentSlot.MAINHAND) return super.getDefaultAttributeModifiers(slot);
        double dmg = attackDamage();
        Modifiers current = cache;
        if (current == null || current.damage() != dmg) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier",
                    dmg - 1.0, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier",
                    attackSpeed, AttributeModifier.Operation.ADDITION));
            if (reach > 0) {
                builder.put(ForgeMod.ENTITY_REACH.get(), new AttributeModifier(REACH_UUID, "Weapon reach",
                        reach, AttributeModifier.Operation.ADDITION));
            }
            current = new Modifiers(dmg, builder.build());
            cache = current;
        }
        return current.map();
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (!(attacker.level() instanceof ServerLevel level)) return result;
        Vec3 c = target.getBoundingBox().getCenter();
        switch (ability) {
            case SELF_REPAIR -> {
                if (stack.isDamaged()) stack.setDamageValue(Math.max(0, stack.getDamageValue() - 3));
            }
            case CHAKRA_DRAIN -> {
                if (!(attacker instanceof ServerPlayer player)) break;
                NinjaData data = NinjaData.get(player);
                if (data == null) break;
                float gained = Config.f(Config.SAMEHADA_FEED);
                if (target instanceof ServerPlayer victim && victim != player) {
                    gained += com.shinobiarts.ninja.PlayerDataManager.drainChakra(victim, Config.f(Config.SAMEHADA_STEAL));
                }
                if (gained > 0) {
                    data.addChakra(gained);
                    ModNetwork.sync(player);
                }
                level.sendParticles(ParticleTypes.SOUL, c.x, c.y, c.z, 6, 0.3, 0.4, 0.3, 0.02);
            }
            case CHIDORI_FLOW -> {
                if (!(attacker instanceof ServerPlayer player)) break;
                NinjaData data = NinjaData.get(player);
                float cost = Config.f(Config.KUSANAGI_CHAKRA_COST);
                if (data == null || data.getChakra() < cost) break;
                data.consumeChakra(cost);
                ModNetwork.sync(player);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 3), attacker);
                level.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 14, 0.3, 0.4, 0.3, 0.3);
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.TRIDENT_HIT, SoundSource.PLAYERS, 0.6f, 1.8f);
            }
            case BURN -> {
                target.setSecondsOnFire(5);
                level.sendParticles(ParticleTypes.FLAME, c.x, c.y, c.z, 10, 0.3, 0.4, 0.3, 0.03);
            }
            case KNOCKBACK -> {
                target.knockback(1.2, Math.sin(Math.toRadians(attacker.getYRot())), -Math.cos(Math.toRadians(attacker.getYRot())));
                level.playSound(null, target.getX(), target.getY(), target.getZ(), SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 0.5f, 1.6f);
            }
            default -> {
            }
        }
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (ability != Ability.NONE) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.weapon." + ability.name().toLowerCase(java.util.Locale.ROOT))
                    .withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.weapon.kenjutsu").withStyle(ChatFormatting.GRAY));
    }
}
