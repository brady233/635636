package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.NinjaWeaponItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Weapon effects that need the final damage number (after armor), like the Jashin ritual's healing. */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class WeaponEvents {
    private WeaponEvents() {}

    @SubscribeEvent
    public static void onDamage(LivingDamageEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player) || event.getSource().getDirectEntity() != player) return;
        if (!event.getSource().is(DamageTypes.PLAYER_ATTACK) || event.getAmount() <= 0 || event.getEntity() == player) return;
        if (!(player.getMainHandItem().getItem() instanceof NinjaWeaponItem weapon)) return;
        if (weapon.ability() == NinjaWeaponItem.Ability.LIFESTEAL && player.getHealth() < player.getMaxHealth()) {
            player.heal(event.getAmount() * Config.f(Config.HIDAN_LIFESTEAL));
            player.serverLevel().sendParticles(ParticleTypes.DAMAGE_INDICATOR, player.getX(), player.getY(1.0), player.getZ(),
                    4, 0.3, 0.2, 0.3, 0.05);
        }
    }
}
