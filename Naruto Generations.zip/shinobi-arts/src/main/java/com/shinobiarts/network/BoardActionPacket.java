package com.shinobiarts.network;

import com.shinobiarts.quest.QuestBoard;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: a button on the quest board or Kage menu. The server checks everything. */
public class BoardActionPacket {
    public static final int ACCEPT = 0, DECLINE = 1, CLAIM = 2, POST = 3, REMOVE = 4, PROMOTE = 5, STORAGE = 6, OPEN_KAGE = 7, REFRESH = 8, ADVISOR = 9;

    private final int action;
    private final String text;
    private final int a;
    private final int b;
    private final long c;

    public BoardActionPacket(int action, String text, int a, int b, long c) {
        this.action = action;
        this.text = text == null ? "" : text;
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public BoardActionPacket(FriendlyByteBuf buf) {
        this.action = buf.readVarInt();
        this.text = buf.readUtf(64);
        this.a = buf.readVarInt();
        this.b = buf.readVarInt();
        this.c = buf.readVarLong();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action);
        buf.writeUtf(text, 64);
        buf.writeVarInt(a);
        buf.writeVarInt(b);
        buf.writeVarLong(c);
    }

    public int action() {
        return action;
    }

    public String text() {
        return text;
    }

    public int a() {
        return a;
    }

    public int b() {
        return b;
    }

    public long c() {
        return c;
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) QuestBoard.handle(player, this);
    }
}
