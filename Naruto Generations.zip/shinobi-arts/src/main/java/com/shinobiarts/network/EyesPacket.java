package com.shinobiarts.network;

import com.shinobiarts.client.ClientEyes;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: which Sharingan stage a player's face shows right now (0 = eyes off). */
public class EyesPacket {
    private final int entityId;
    private final int stage;

    public EyesPacket(int entityId, int stage) {
        this.entityId = entityId;
        this.stage = stage;
    }

    public EyesPacket(FriendlyByteBuf buf) {
        this.entityId = buf.readVarInt();
        this.stage = buf.readByte();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeByte(stage);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientEyes.set(entityId, stage));
    }
}
