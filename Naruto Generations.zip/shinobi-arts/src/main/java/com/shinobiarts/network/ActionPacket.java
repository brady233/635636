package com.shinobiarts.network;

import com.shinobiarts.jutsu.ServerActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server: the player pressed a key or a menu button. It only carries the request;
 * the server checks everything (chakra, cooldowns, points, Ryo) before doing anything.
 */
public class ActionPacket {
    public static final int CAST = 0;
    public static final int NEXT = 1;
    public static final int PREV = 2;
    public static final int DOJUTSU = 4;
    public static final int CHARGE_START = 5;
    public static final int CHARGE_STOP = 6;
    public static final int NINJA_JUMP = 7;
    public static final int SAGE_MODE = 8;
    /** arg = stat ordinal, arg2 = points to add. */
    public static final int ALLOCATE_STAT = 9;
    public static final int RESET_STATS = 10;
    /** arg = coin ordinal, or -1 for every coin. */
    public static final int DEPOSIT = 11;
    /** arg = coin ordinal, arg2 = number of coins. */
    public static final int WITHDRAW = 12;
    /** The stats menu's "Leave team" button. */
    public static final int TEAM_LEAVE = 13;
    /** The Jutsu page's "Upgrade" button; arg = the jutsu's index (Jutsus.index). */
    public static final int UPGRADE_JUTSU = 14;

    private final int action;
    private final int arg;
    private final int arg2;

    public ActionPacket(int action) {
        this(action, 0, 0);
    }

    public ActionPacket(int action, int arg, int arg2) {
        this.action = action;
        this.arg = arg;
        this.arg2 = arg2;
    }

    public ActionPacket(FriendlyByteBuf buf) {
        this.action = buf.readVarInt();
        this.arg = buf.readVarInt();
        this.arg2 = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action);
        buf.writeVarInt(arg);
        buf.writeVarInt(arg2);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) ServerActions.handle(player, action, arg, arg2);
    }
}
